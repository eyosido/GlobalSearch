Global Search - Substance 3D Designer plugin
version 1.2.2 - 2019-2022 Eyosido Software SARL
-----------------------------------------------

Substance 3D Designer plugin extending the search capabilities to multiple packages/folders/graphs/functions at a time using various filters. It is especially useful to locate cooking errors into package functions.

Requires Substance Designer 2019.2 or above.

Repository: https://github.com/eyosido/GlobalSearch

UPGRADE AND INSTALLATION
------------------------

If you are upgrading from a previous version of Global Search, you must first delete the existing plugin on your user space, on Windows this is <user home>/Documents/Allegorithmic/Substance Designer/python/sduserplugins and then launch Substance Designer to install the new version of the plugin.

- In Substance Designer, open the Plugin Manager (Tools/Plugin Manager... menu)
- Click the "INSTALL..." button and select the globalsearch.sdplugin file.

Plugin will be installed on your user space (on Windows this is <user home>/Documents/Allegorithmic/Substance Designer/python/sduserplugins) and enabled in the Plugin Manager. You may disable/enable it in the Plugin Manager at any time.

The plugin view is a dock widget integrated into the Designer User Interface. You can resize it, dock it, make it a separate windows just like any other Designer view. If the plugin view is closed it can be restored using the Windows menu.


VERSION HISTORY
---------------
1.2.2:
- Made open-source under MIT license
- the "Everything" text into the Search Into field now hints at hitting the Refresh button to get a Search Into list update.

1.2.1:
- Compatibility update for Substance Designer 2020.1

1.2:
- Function calls inside user functions (either parameter functions or package functions) are now returned part of the search results. This way you can track all the areas where a specific function of yours is being called.
- The search result context menu (right-click on a search result) has been enhanced with more menu items: you can now copy into the clipboard the location or found result term, but you can also launch a new search directly from a search result using the Search menu items.
- Columns in the search result views now adapt their width automatically based on the length of the data they contain.
- Long search results such as comment texts are now shown partially in order to reduce the column width occupation.
- Clearing search history from Preferences now pops up a confirmation dialog.
- The display of parameter functions (parameters being driven by functions) has been improved with a new icon and more consistent display between the tree and list modes of the search results view.

1.1:
- A column with the numerical node identifier (Id) can now be displayed in search results. While it is not yet possible to open items from the search result view due to lack of support from the host, this Id enables to use the Substance Designer's search functionality to find a specific node by Id. You can now right-click on a search result row to which is associated an node Id to pop up a context menu that will copy in the node Id into the clipboard, then paste (CTRL+V) this Id into the Substance Designer's search tool field (Graph view toolbar). The Id column display can be turned on/off in Preferences.
- Improved Param Functions preset search result display with more context information such as name of the node involved and its Id.
- Fixed an issue where searching with preset would not work the second time if edit line had been modified between attempts.
- Fixed the name display of graph-based nodes that could be empty.
- The GlobalSearch widget now closes when the plugin is disabled. When re-enabled, it must be selected from the Windows menu to show up again.

1.0.3:
- Added a status line displaying result count, failed searches etc.
- When searching intro graphs, entering custom sub-graphs and package functions options are now disabled by default (can be enabled in Preferences when needed) as they extend the search time and can also be found independently when searching from the package root.
- Fixed an issue that could lead to not display certain search results in specific situations.

1.0.2:
- Added the following search options in Preferences:
  . Enter custom sub-graphs: tells whether user sub graphs found into graphs should be searched. Since those sub-graphs are also independently present in the package, using this option may lead to duplicate search results and longer search times. 
  . Enter pkg functions in graphs: tells whether package functions found in graph's parameter functions should be searched into. Since those functions are also independently present in the package, using this option may lead to duplicate search results and longer search times.
- Fixed inability to search into custom sub-graphs.

1.0.1:
- Minor packaging modification

1.0:
Initial telease


TYPICAL USE CASES:
------------------
- Search for terms in frames or comments, input parameters, variable names, graph names, function names etc.
- Determine which graph parameters have custom functions.
- Determine which areas are left to be worked on or temporary and need to be removed before production using TODO and TMP markers.
- Find specific variables into functions including package functions, in particular when involved in cooking errors.
- Find places where specific variables are being assigned (Set) in functions.


FEATURES
--------
- Searches text or presets into multiple packages/folders/graphs/functions from a user-defined search root. The list of possible search roots can be refreshed if items have been added/removed in the Explorer view.

- Persistent search filters enabling to search into the following fields:
    . graph name (ID or label)
	. Folder name (ID)
	. Comments and frames
	. Package function names (ID or label)
	. Package function input parameter names (ID)
	. Variables or input parameters in function Get nodes (including Package function)
	. Variables or input parameters in function Set nodes (including Package function)
	
  These search capabilities, in particular the ability to find variable Get/Set usage into package functions are especially useful when developing function code as cooking errors currently do not identify the package function in which an error is present. If the error is related to a variable, the search tool enables to quickly find it.

- Search presets override search filters and search for specific information. The following presets are available:
    . Param functions: searches all graph input parameters to which are assigned custom parameter functions. In a large graph, it is easy to loose track of the input parameters having custom functions, this preset lets you identify them.
	. TODO: searches for TODO strings that can be left in comments to indicate a feature left to implement. This way you can easily manage a TODO list of what's left to do in your graphs.
	. TMP: searches for TMP strings that can be left in comments to indicate a temporary feature that needs to be removed before final release.

- Two search modes: Natural searches for text contained into the items determined by search filters. If not using Natural mode, search is made for exact match, in this case the * wildcard character may be used at the beginning or end of the search text find items by prefix or suffix. Search can be made case sensitive or not.

- Search results presented as hierarchical (Tree) or flat (List) view. In List mode, search results can be sorted by column.

- Persistent Search history keeping the last searches having returned results. Search History can be cleaned in Preferences.


USAGE
-----
After a package (.sbs) is opened into Designer, the Refresh button (to the right of the Search Into field) must be clicked so the plugin can refresh its list of content to search into.

Use the Search Into field to reduce the search scope to a specific set of components (graphs, package functions etc.).

To perform a search, enter some text in the search field then hit Enter or the Search button (magnifying glass icon). The search field is a popup containing a history of searches. This history may be cleared in the plugin's Preferences (cogwheel icon).

Search results are presented in a Tree view by default, where the result hierarchy may be expanded/collapsed locally. This may be changed to List view by clicking the List icon. The search result view has several columns, you may increase the width of the view if they are not visible by default. Right-cliking on a search result enables to copy into the clipboard various information as well as start a new search from a found result (for example a function name). Search results may be cleared using the Clear button (red X icon). A text at the bottom of the view indicates how many results have been found, or whether no results have been found.


KNOWN ISSUES
------------

- tree view node expand/collase in the Search Into combo box/tree may occasionnaly stop working. If this happens, click the Refresh button to the right of the Search Into combo box.
- there is no way to open a search result inside a Substance Designer view.
- frame titles are not currently searchable.
- the content of functions attached to FX-Map's internal graph nodes is not searchable.





